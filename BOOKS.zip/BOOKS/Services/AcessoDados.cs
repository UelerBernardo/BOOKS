﻿// vamos importar biblioteca no Banco
using System;
using System.Data;
using System.Data.SqlClient;


namespace BOOKS.Services
{
    public class AcessoDados
    {
        //metodo para conectar com o banco de dados
        private SqlConnection CriarConexao()
        {
            SqlConnection conexao = new SqlConnection();
            //aqui vamos criar a string de conexao para conectar no banco
            //Data Source = servidor
            //Initial Catalog = Nome do Banco 
            //Integrated Security Autenticação do Windows
            //User Instance vai pegar o usuário que está logado na máquina
            conexao.ConnectionString = "Data Source=DESKTOP-35TJI5Q\\SQLEXPRESS01;" + "Initial Catalog=BOOKS;" + "Integrated Security=SSPI;" + "User Instance=false;";

            conexao.Open();// Abrir a conexão 
            return conexao;

        }

        //aqui vamos criar uma varivel golbal para armazenar os parametros do sql.
        private SqlParameterCollection sqlParameterCollection = new SqlCommand().Parameters;

        public void LimparParametros()
        {
            sqlParameterCollection.Clear();
        }
        public void AdicionarParametro(string nomeParametro, object valorParametro)
        {
            sqlParameterCollection.Add(new SqlParameter(nomeParametro, valorParametro) );
        }

        //aqui vamos começar as manipulações INSERT - UPDATE - DELETE
        [Obsolete]
        public int ExecutarManipulacao(
            CommandType commandType,
            string nomeStoredProcedureOuTextpSql)
        {
            try
            {
                SqlConnection sqlConnection = CriarConexao();
                SqlCommand sqlCommand = sqlConnection.CreateCommand();

                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredProcedureOuTextpSql;

                foreach (SqlParameter sqlParameter in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(
                        new SqlParameter(sqlParameter.ParameterName,
                                            sqlParameter.Value));
                }

                //Executa o comando SQL e retorna quantas linhas afetadas
                return sqlCommand.ExecuteNonQuery();
            }
            //Adicionar a biblioteca using System;
            catch (Exception ex)
            {
                //Retorno o erro a onde o Método foi chamado
                throw new Exception("Houve uma falha ao execuar o " +
                    "comando no banco de dados.\r\n" +
                    "Mensagem original: " + ex.Message);
            }
        }

        //Metodo para realizar as consultas no banco de dados
        [Obsolete]
        public DataTable ExecutarConsulta(CommandType commandtype, string StoredOuTextSql)
        {
            try
            {
                //abrimos a conexão com o banco aqui
                SqlConnection sqlConnection = CriarConexao();
                //criar a variavél do comando que sera executado
                SqlCommand sqlCommand = sqlConnection.CreateCommand();
                //aqui vamos definir o tipo de comando 
                sqlCommand.CommandType = commandtype;
                sqlCommand.CommandText = StoredOuTextSql;
                foreach (SqlParameter sqlParameter in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(sqlParameter.ParameterName, sqlParameter.Value);
                }
                //quando o retorno é um datatable, o C# precisa que ele se torne um objeto
                //iremos usar o sqldataadpter para fazer o retorno do banco converter em datatble
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();
                //Nesse momento o comando é executado, e com isso convertemos a tabela vinda do banco para datatable
                return dataTable;
            }
            catch (Exception ex) 
            {
                throw new Exception("Houve uma falha" + "na consulta no banco de dados" + "\r\n" + "Mensagem original" + ex.Message);
            }

        }

        //Metodo consulta escalar para retornar uma única informação
        [Obsolete]
        public object ExecutarConsultaEsacalar(CommandType commandType, string nomeStoredeOuTextoSql)
        {
            try
            {
                //abrimos a conexão com o banco aqui
                SqlConnection sqlConnection = CriarConexao();
                //criar a variavél do comando que sera executado
                SqlCommand sqlCommand = sqlConnection.CreateCommand();
                //aqui vamos definir o tipo de comando 
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredeOuTextoSql;
                //aqui vamos carregar os parametro

                foreach (SqlParameter sqlParameter in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(sqlParameter.ParameterName, sqlParameter.Value);


                }
                return sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                //aqui crio a mensagem tratada
                //\r\b =  quebra de linha
                throw new Exception("Houve uma falha" + "a consult escalar no  de dados" + "\r\n" + "Mensagem original" + ex.Message);
            }
        }
    }
}