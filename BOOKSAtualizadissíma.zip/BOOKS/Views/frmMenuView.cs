﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOKS.Views
{
    public partial class frmMenuView : Form
    {
        public frmMenuView()
        {
            InitializeComponent();
            AtualizarDataHora();
            
        }
        public void AtualizarDataHora()
        {
            lblHora.Text = DateTime.Now.ToLongTimeString();
            lblData.Text = DateTime.Now.ToLongDateString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tstSite_Click(object sender, EventArgs e)
        {
            Process.Start("https://leitura.com.br");
        }

        private void tstHost_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            AtualizarDataHora();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void frmMenuView_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Deseja sair ?",
               "Atenção",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Warning,
               MessageBoxDefaultButton.Button2
               ) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmClienteSelecaoView frm = new frmClienteSelecaoView();
            frm.ShowDialog();
        }
        private void btnCliente_Click(object sender, EventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void livroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProdutoSelecao frm = new frmProdutoSelecao();
            frm.ShowDialog();
        }

        private void pedidoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPedidoView frm = new frmPedidoView();
            frm.ShowDialog();
        }
    }
}
