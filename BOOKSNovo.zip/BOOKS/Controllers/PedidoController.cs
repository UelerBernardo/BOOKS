﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using BOOKS.Models;
using BOOKS.Services;

namespace BOOKS.Controllers
{
    public class PedidoController
    {
        AcessoDados dataBase = new AcessoDados();

        public int Inserir(Pedido pedido)
        {
            string query = "INSERT INTO tblPedido (DataHora, ClienteID, SituacaPedido)" +
                "VALUES (@DataHora, @ClienteID, @SituacaPedido)";


            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@DataHora", pedido.DataHora);
            dataBase.AdicionarParametro("@ClienteID", pedido.cliente.ClienteID);
            dataBase.AdicionarParametro("@SituacaPedido", pedido.SituacaPedido);

            dataBase.ExecutarManipulacao(CommandType.Text, query);

            return Convert.ToInt32(dataBase.ExecutarConsultaEsacalar(
                CommandType.Text, "SELECT MAX(PedidoID) FROM tblPedido"));
        }
        public int Alterar(Pedido pedido)
        {
            string query = "UPDATE tblPedido SET +" +
                "DataHora = @DataHora, " +
                "ClienteID = @ClienteID, " +
                "SituacaPedido = @SituacaPedido " +
                "WHERE PedidoID = @PedidoID";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@DataHora", pedido.DataHora);
            dataBase.AdicionarParametro("@ClienteID", pedido.cliente.ClienteID);
            dataBase.AdicionarParametro("@SituacaPedido", pedido.SituacaPedido);

            return dataBase.ExecutarManipulacao(CommandType.Text, query);
        }

        public int Apagar(int PedidoID)
        {
            string query = "DELETE FROM tblPedido WHERE PedidoID = @PedidoID";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("PedidoID", PedidoID);

            return dataBase.ExecutarManipulacao(CommandType.Text, query);
        }
        public PedidoColecao ConsultarTodos()
        {
            PedidoColecao pedidoColecao = new PedidoColecao();
            ClienteControle clienteColecao = new ClienteControle();
            PedidoItemColecao pedidoItemColecao = new PedidoItemColecao();

            string query = "SELECT * FROM tblPedido";

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, query);

            foreach (DataRow datarow in dataTable.Rows)
            {
                Pedido pedido = new Pedido();
                pedido.PedidoID = Convert.ToInt32(datarow["PedidoID"]);
                pedido.DataHora = Convert.ToDateTime(datarow["DataHora"]);
                pedido.cliente = clienteColecao.ConsultarPorID(Convert.ToInt32(datarow["ClienteID"]));
                pedido.SituacaPedido = Convert.ToChar(datarow["SituacaPedido"]);

                pedidoColecao.Add(pedido);
            }
            return pedidoColecao;
        }

        public PedidoColecao ConsultarPorPeriodo(DateTime dtInicial, DateTime dtFinal)
        {
            PedidoColecao pedidoColecao = new PedidoColecao();
            ClienteControle clienteColecao = new ClienteControle();
            PedidoItemController pedidoItemColecao = new PedidoItemController();

            string query = "SELECT * FROM tblPedido " +
                "WHERE DataHora BETWEEN @dtInicial AND @dtFinal";

            DateTime dtInicialZeroHoras = dtInicial.Date;
            DateTime dtFinalUltimaHora = new DateTime(dtFinal.Year, dtFinal.Month, dtFinal.Day, 23, 59, 59);

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@DtInicial", dtInicialZeroHoras);
            dataBase.AdicionarParametro("@DtFinal", dtFinalUltimaHora);

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, query);

            foreach (DataRow datarow in dataTable.Rows)
            {
                Pedido pedido = new Pedido();
                pedido.PedidoID = Convert.ToInt32(datarow["PedidoID"]);
                pedido.DataHora = Convert.ToDateTime(datarow["DataHora"]);
                pedido.cliente = clienteColecao.ConsultarPorID(Convert.ToInt32(datarow["ClienteID"]));
                pedido.SituacaPedido = Convert.ToChar(datarow["SituacaPedido"]);
                pedido.ValorTotal = pedidoItemColecao.ValorTotalItensItensDoPedido(pedido.PedidoID);

                pedidoColecao.Add(pedido);
            }
            return pedidoColecao;
        }

        public PedidoColecao ConsultarPorCampo(string campo, string valor)
        {
            PedidoColecao pedidoColecao = new PedidoColecao();
            ClienteControle clienteControle = new ClienteControle();
            PedidoItemController pedidoItemController = new PedidoItemController();

            string query = "SELECT * FROM tblPedido " +
                "WHERE " + campo + " = @Valor";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@Valor", valor);

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, query);

            foreach (DataRow dataRow in dataTable.Rows)
            {
                Pedido pedido = new Pedido();
                pedido.PedidoID = Convert.ToInt32(dataRow["PedidoID"]);
                pedido.DataHora = Convert.ToDateTime(dataRow["DataHora"]);
                pedido.cliente = clienteControle.ConsultarPorID(Convert.ToInt32(dataRow["ClienteID"]));
                pedido.SituacaPedido = Convert.ToChar(dataRow["SituacaPedido"]);
                pedido.ValorTotal = pedidoItemController.ValorTotalItensItensDoPedido(pedido.PedidoID);

                pedidoColecao.Add(pedido);
            }
            return pedidoColecao;
        }

        public int AlterarStatus(int idPedido, char status)
        {
            string query = "UPDATE tblPedido SET " +
                            "SituacaPedido = @Status " +
                            "WHERE PedidoID = @IdPedido";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", idPedido);
            dataBase.AdicionarParametro("@Status", status);

            return dataBase.ExecutarManipulacao(CommandType.Text, query);
        }
    }
}