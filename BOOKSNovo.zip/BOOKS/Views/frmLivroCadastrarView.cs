﻿using BOOKS.Controllers;
using BOOKS.Models;
using BOOKS.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOKS.Views
{
    public partial class frmLivroCadastrarView : Form
    {
        AcaoNaTela acaoSelecionada;
        Livro livroSelecionado;
        public frmLivroCadastrarView(AcaoNaTela acaoTela, Livro livro)
        {
            InitializeComponent();
            acaoSelecionada = acaoTela;
            livroSelecionado = livro;

            if (acaoSelecionada == AcaoNaTela.Inserir)
                this.Text = "Cadastrar livro";
            else
            {
                CarregarDados();

                if (acaoSelecionada == AcaoNaTela.Alterar)
                    this.Text = "Alterar livro";
                else
                {
                    this.Text = "Visualizar livro";
                    DesabilitarCampos();
                }
            }
        }

        private void frmLivroCadastrarView_Load(object sender, EventArgs e)
        {

        }
        private void frmlivroCadastroView_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (acaoSelecionada != AcaoNaTela.Visualizar)
                if (MessageBox.Show("Deseja realmente sair?", "Confirmação...",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                    e.Cancel = true;
        }

        private void btnSalvar_Click(object sender, System.EventArgs e)
        {
            Salvar();
        }

        private void btnCancelar_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
        #region Métodos
        private void CarregarDados()
        {
            txtLivroID.Text = livroSelecionado.LivroID.ToString();
            txtNomeBook.Text = livroSelecionado.LivroNome;
            txtISBN.Text = livroSelecionado.CodigoISBN.ToString();
            txtGen.Text = livroSelecionado.LivroGenero;
            txtPrecoVenda.Text = string.Format("{0:N2}", livroSelecionado.Preco);
            txtQtdPag.Text = livroSelecionado.QuantidadePaginas.ToString();
            txtAutorNome.Text = livroSelecionado.NomeAutor;
        }

        private void DesabilitarCampos()
        {
            txtNomeBook.ReadOnly = true;
            txtISBN.ReadOnly = true;
            txtGen.ReadOnly = true;
            txtPrecoVenda.ReadOnly = true;
            txtQtdPag.ReadOnly = true;
            txtAutorNome.ReadOnly = true;
            btnSalve.Visible = false;
            btnCancel.Visible = false;
        }

        private void Salvar()
        {
            if (!string.IsNullOrEmpty(txtNomeBook.Text))
            {
                Livro livro = new Livro();

                livro.LivroNome = txtNomeBook.Text;
                livro.LivroGenero = txtGen.Text;
                livro.CodigoISBN = Convert.ToInt32(txtISBN.Text);
                livro.QuantidadePaginas = Convert.ToInt32(txtQtdPag.Text);
                livro.NomeAutor = txtAutorNome.Text;

                string precoVenda = txtPrecoVenda.Text.Replace(".", "");
                decimal preco = 0;
                if (decimal.TryParse(precoVenda, out preco))
                    livro.Preco = preco;



                else
                {
                    MessageBox.Show("Digite uma quantidade de estoque válida.", "Atenção...",
                       MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtQuantidadeParginas.Focus();
                    return;
                }

                livroController livroController = new livroController();
                int retonoSql = 0;

                if (acaoSelecionada == AcaoNaTela.Inserir)
                    retonoSql = livroController.Inserir(livro);
                else
                {
                    livro.LivroID = int.Parse(txtLivroID.Text);
                    retonoSql = livroController.Alterar(livro);
                }

                if (retonoSql > 0)
                {
                    if (acaoSelecionada == AcaoNaTela.Inserir)
                        txtId.Text = retonoSql.ToString();

                    MessageBox.Show("Registro salvo com sucesso!", "Informação",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Falha ao salvar registro", "Erro",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Preencha os campos corretamente", "Atenção",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        #endregion

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            Salvar();
            Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Salvar();
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
