﻿using BOOKS.Controllers;
using BOOKS.Models;
using System;
using System.Windows.Forms;
using System.Reflection;

namespace BOOKS.Views
{
    public partial class frmPedidoVisualizacaoView : Form
    {
        Pedido pedidoSelecionado;

        PedidoItemController pedidoItemController = new PedidoItemController();
        public frmPedidoVisualizacaoView(Pedido pedido)
        {
            InitializeComponent();
            dgvPedidoItens.AutoGenerateColumns = false;

            pedidoSelecionado = pedido;
        }

       
        private void frmPedidoVisualizacaoView_Load(object sender, EventArgs e)
        {
            CarregarPropriedades();
            CarregarProdutos();
        }
        private void dgvPedidoItens_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            try
            {
                if ((dgvPedidoItens.Rows[e.RowIndex].DataBoundItem != null) &&
                    (dgvPedidoItens.Columns[e.ColumnIndex].DataPropertyName.Contains(".")))
                {
                    //e.Value = CarregarPropriedades(dgvPedidoItens.Rows[e.RowIndex].DataBoundItem,
                        //dgvPedidoItens.Columns[e.ColumnIndex].DataPropertyName); Isso  tem alterar para dar certa a visualização
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Atenção...", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void CarregarPropriedades()
        {
            txtIdCliente.Text = pedidoSelecionado.cliente.ClienteID.ToString();
            txtNomeCliente.Text = pedidoSelecionado.cliente.ClienteNome;
            txtIdPedido.Text = pedidoSelecionado.PedidoID.ToString();
            txtDataHora.Text = pedidoSelecionado.DataHora.ToShortDateString();
            lblValorTotal.Text = "Valor total: R$ " + string.Format("{0:N2}", pedidoSelecionado.ValorTotal);
        }

        private void CarregarProdutos()
        {
            dgvPedidoItens.DataSource = null;
            dgvPedidoItens.DataSource = pedidoItemController.ConsultarTodosItensDoPedido(pedidoSelecionado.PedidoID);
            dgvPedidoItens.Update();
            dgvPedidoItens.Refresh();
        }
    }
}
