﻿using BOOKS.Controllers;
using BOOKS.Models;
using BOOKS.Services;
using System.Windows.Forms;
using BOOKS.Views;

namespace BOOKS.Views
{
    public partial class frmProdutoSelecao : Form

    {
        public Livro produtoselecionado;
        public frmProdutoSelecao()
        {
            InitializeComponent();

        }
        private Livro RecuperarRegistro()
        {
            if (dgvRegistros.SelectedRows.Count == 0)
            {
                MessageBox.Show("Nenhum registro selecionado.", "Informação",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }
            else
            {
                return dgvRegistros.SelectedRows[0].DataBoundItem as Livro;
            }
        }

        private void Pesquisar()
        {
            int id = 0;

            livroController produtoController = new livroController();
            LivroColecao podutoCollection = new LivroColecao();
            dgvRegistros.DataSource = null;

            if (int.TryParse(txtPesquisa.Text, out id))
            {
                Livro produto = produtoController.ConsultarPorId(id);
                if (produto != null)
                    podutoCollection.Add(produto);
            }
            else
                podutoCollection = produtoController.ConsultarPorDescricao(txtPesquisa.Text.Trim());

            dgvRegistros.DataSource = podutoCollection;
            dgvRegistros.Update();
            dgvRegistros.Refresh();
        }

        private void Excluir()
        {
            Livro produtoSelecionado = RecuperarRegistro();

            if (produtoSelecionado != null)
            {
                if (MessageBox.Show("Deseja realmente excluir o registro?", "Confirmação",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    livroController clienteController = new livroController();

                    if (clienteController.Apagar(produtoSelecionado.LivroID) > 0)
                    {
                        MessageBox.Show("Registro excluído com sucesso.", "Informação",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

                        Pesquisar();
                    }
                    else
                        MessageBox.Show("Não foi possível excluir o regsitro.", "Atenção",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void ChamarTelaCadastro(AcaoNaTela acaoTela, Livro produto)
        {
            frmLivroCadastrarView frm = new frmLivroCadastrarView(acaoTela, produto);
            frm.ShowDialog();

            if (acaoTela != AcaoNaTela.Visualizar)
                Pesquisar();
        }

        private void Selecionar()
        {
            produtoselecionado = RecuperarRegistro();
            if (produtoselecionado != null)
                this.DialogResult = DialogResult.OK;
        }

        private void btnPesquisar_Click(object sender, System.EventArgs e)
        {
            Pesquisar();
        }

        private void btnCadastrar_Click(object sender, System.EventArgs e)
        {
            frmLivroCadastrarView frm = new frmLivroCadastrarView(0, null);
            frm.ShowDialog();
        }

        private void btnAlterar_Click(object sender, System.EventArgs e)
        {
            ChamarTelaCadastro(AcaoNaTela.Alterar, RecuperarRegistro());
        }

        private void btnExcluir_Click(object sender, System.EventArgs e)
        {
            Excluir();
        }

        private void btnVisualizar_Click(object sender, System.EventArgs e)
        {
            ChamarTelaCadastro(AcaoNaTela.Visualizar, RecuperarRegistro());
        }
    }
}
