﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKS.Models
{
    public class Livro
    {
        public int LivroID { get; set; }
        public string LivroNome { get; set; }
        public int QuantidadePaginas { get; set; }
        public string NomeAutor { get; set; }
        public string LivroGenero { get; set; }
        public decimal Preco { get; set; }
        public int CodigoISBN { get; set; }
    }
}
