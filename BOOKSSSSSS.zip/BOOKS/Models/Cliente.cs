﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKS.Models
{
    public class Cliente
    {
        public int ClienteID { get; set; }
        public string ClienteNome { get; set; }
        public string Email { get; set; }
        public string ClienteTelefone { get; set; }
        public string ClienteCPF { get; set; }
    }
}
