﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using BOOKS.Models;
using BOOKS.Services;
using System.Data.SqlClient;

namespace BOOKS.Controllers
{

    public class PedidoItemController
    {
        AcessoDados dataBase = new AcessoDados();

        [Obsolete]
        public int Inserir(PedidoItem pedidoItem)
        {
            string queryInserir = "INSERT INTO pedido_item (id_pedido, id_produto, quantidade, valor_unitario, valor_total) " +
                "VALUES (@IdPedido, @IdProduto, @Quantidade, @ValorUnitario, @ValorTotal);";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", pedidoItem.pedido.PedidoID);
            dataBase.AdicionarParametro("@IdProduto", pedidoItem.livro.LivroID);
            dataBase.AdicionarParametro("@Quantidade", pedidoItem.Quantidade);
            dataBase.AdicionarParametro("@ValorUnitario", pedidoItem.ValorUnitario);
            dataBase.AdicionarParametro("@ValorTotal", pedidoItem.ValorTotal);

            dataBase.ExecutarManipulacao(CommandType.Text, queryInserir);

            return Convert.ToInt32(dataBase.ExecutarConsultaEsacalar(CommandType.Text, "SELECT MAX(id_pedido_item) FROM pedido_item"));

        }

        [Obsolete]
        public int Alterar(PedidoItem pedidoItem)
        {
            string queryAlterar = "UPDATE pedido_item SET id_produto = @IdProduto, quantidade = @Quantidade, " +
                "valor_unitario = @ValorUnitario, valor_total = @ValorTotal WHERE id_pedido = @IdPedido AND id_pedido_item = @IdPedidoItem";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", pedidoItem.pedido.PedidoID);
            dataBase.AdicionarParametro("@IdPedidoItem", pedidoItem.PedidoItemID);
            dataBase.AdicionarParametro("@IdProduto", pedidoItem.livro.LivroID);
            dataBase.AdicionarParametro("@Quantidade", pedidoItem.Quantidade);
            dataBase.AdicionarParametro("@ValorUnitario", pedidoItem.ValorUnitario);
            dataBase.AdicionarParametro("@ValorTotal", pedidoItem.ValorTotal);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryAlterar);
        }

        [Obsolete]
        public int Apagar(int IdPedido, int IdPedidoItem)
        {
            string queryApagar = "DELETE FROM pedido_item WHERE id_pedido = @IdPedido AND id_pedido_item = @IdPedidoItem";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", IdPedido);
            dataBase.AdicionarParametro("@IdPedidoItem", IdPedidoItem);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryApagar);
        }

        [Obsolete]
        public PedidoItemColecao ConsultarTodosItensDoPedido(int IdPedido)
        {
            PedidoItemColecao pedidoItemCollection = new PedidoItemColecao();
            livroController produtoController = new livroController();
            //PedidoController pedidoController = new PedidoController();

            string queryConsulta = "SELECT * FROM pedido_item WHERE id_pedido = @IdPedido ORDER BY id_pedido_item";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", IdPedido);

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, queryConsulta);

            foreach (DataRow dataRow in dataTable.Rows)
            {
                PedidoItem pedidoItem = new PedidoItem();
               // pedidoItem.pedido = pedidoController.ConsultarPorId(Convert.ToInt32(dataRow["id_pedido"]));
                pedidoItem.livro = produtoController.ConsultarPorId(Convert.ToInt32(dataRow["id_produto"]));
                pedidoItem.PedidoItemID = Convert.ToInt32(dataRow["id_pedido_item"]);
                pedidoItem.Quantidade = Convert.ToInt32(dataRow["quantidade"]);
                pedidoItem.ValorUnitario = Convert.ToDecimal(dataRow["valor_unitario"]);
                pedidoItem.ValorTotal = Convert.ToDecimal(dataRow["valor_total"]);

                pedidoItemCollection.Add(pedidoItem);
            }
            return pedidoItemCollection;
        }

        [Obsolete]
        public decimal ValorTotalItensItensDoPedido(int IdPedido)
        {
            string query = "SELECT SUM(valor_total) FROM pedido_item WHERE id_pedido = @IdPedido";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", IdPedido);

            var retorno = dataBase.ExecutarConsultaEsacalar(CommandType.Text, query);

            return Convert.ToDecimal(retorno is DBNull ? 0 : retorno);
        }
    }
}
