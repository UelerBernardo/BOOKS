﻿using BOOKS.Controllers;
using BOOKS.Models;
using BOOKS.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BOOKS.Views
{
    public partial class frmlivroCadastrarView : Form
    {
        AcaoNaTela acaoSelecionada;
        Livro livroSelecionado;
        public frmlivroCadastrarView(AcaoNaTela acaoTela, Livro livro)
        {
            InitializeComponent();
            acaoSelecionada = acaoTela;
            livroSelecionado = livro;

            if (acaoSelecionada == AcaoNaTela.Inserir)
                this.Text = "Cadastrar livro";
            else
            {
                CarregarDados();

                if (acaoSelecionada == AcaoNaTela.Alterar)
                    this.Text = "Alterar livro";
                else
                {
                    this.Text = "Visualizar livro";
                    DesabilitarCampos();
                }
            }
        }

        public frmlivroCadastrarView()
        {
        }

        private void frmlivroCadastroView_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (acaoSelecionada != AcaoNaTela.Visualizar)
                if (MessageBox.Show("Deseja realmente sair?", "Confirmação...",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                    e.Cancel = true;
        }

        private void btnSalvar_Click(object sender, System.EventArgs e)
        {
            Salvar();
        }

        private void btnCancelar_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
        #region Métodos
        private void CarregarDados()
        {
            txtId.Text = livroSelecionado.LivroID.ToString();
            txtLivroNome.Text = livroSelecionado.LivroNome;
            txtBarras.Text = livroSelecionado.CodigoISBN.ToString();
            txtLivroGenero.Text = livroSelecionado.LivroGenero;
            txtPreco.Text = string.Format("{0:N2}", livroSelecionado.Preco);
            txtQuantidadeParginas.Text = livroSelecionado.QuantidadePaginas.ToString();
            txtNomeAutor.Text = livroSelecionado.NomeAutor;
        }

        private void DesabilitarCampos()
        {
            txtLivroNome.ReadOnly = true;
            txtBarras.ReadOnly = true;
            txtLivroGenero.ReadOnly = true;
            txtPreco.ReadOnly = true;
            txtQuantidadeParginas.ReadOnly = true;
            btnSalvar.Visible = false;
            btnCancelar.Visible = false;
        }

        private void Salvar()
        {
            if (!string.IsNullOrEmpty(txtLivroNome.Text))
            {
                Livro livro = new Livro();

                livro.LivroNome = txtLivroNome.Text;
                livro.LivroGenero = txtLivroGenero.Text;
                livro.CodigoISBN = Convert.ToInt32(txtBarras.Text);
                livro.QuantidadePaginas = Convert.ToInt32(txtQuantidadeParginas.Text);
                livro.NomeAutor = txtNomeAutor.Text;

                string precoVenda = txtPreco.Text.Replace(".", "");
                decimal preco = 0;
                if (decimal.TryParse(precoVenda, out preco))
                    livro.Preco = preco;

                

                else
                {
                    MessageBox.Show("Digite uma quantidade de estoque válida.", "Atenção...",
                       MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtQuantidadeParginas.Focus();
                    return;
                }

                livroController livroController = new livroController();
                int retonoSql = 0;

                if (acaoSelecionada == AcaoNaTela.Inserir)
                    retonoSql = livroController.Inserir(livro);
                else
                {
                    livro.LivroID = int.Parse(txtId.Text);
                    retonoSql = livroController.Alterar(livro);
                }

                if (retonoSql > 0)
                {
                    if (acaoSelecionada == AcaoNaTela.Inserir)
                        txtId.Text = retonoSql.ToString();

                    MessageBox.Show("Registro salvo com sucesso!", "Informação",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Falha ao salvar registro", "Erro",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Preencha os campos corretamente", "Atenção",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        #endregion

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            Salvar();
            Close();

        }
    }
}

